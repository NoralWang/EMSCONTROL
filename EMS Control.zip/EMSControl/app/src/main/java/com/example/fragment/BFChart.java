package com.example.fragment;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.emscontrol.R;
import com.example.emsserver.SocketFactoryR;

import android.graphics.Color;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.Spinner;
//import com.alibaba.fastjson.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

import lecho.lib.hellocharts.formatter.LineChartValueFormatter;
import lecho.lib.hellocharts.formatter.SimpleLineChartValueFormatter;
import lecho.lib.hellocharts.gesture.ZoomType;
import lecho.lib.hellocharts.model.Axis;
import lecho.lib.hellocharts.model.AxisValue;
import lecho.lib.hellocharts.model.Line;
import lecho.lib.hellocharts.model.LineChartData;
import lecho.lib.hellocharts.model.PointValue;
import lecho.lib.hellocharts.model.ValueShape;
import lecho.lib.hellocharts.model.Viewport;
import lecho.lib.hellocharts.view.LineChartView;

public class BFChart extends Fragment {

    private LineChartView lineChart;
    private View root;
    private List<PointValue> mPointValues = new ArrayList<PointValue>();
    private List<AxisValue> mAxisXValues = new ArrayList<AxisValue>();
    private Button btntemp;
    private Button btnhumidity;
    private Button btnch2o;
    private Button btnco2;
    private Button btntovc;
    private Button btnpm25;
    private Button btnpm10;
    private Spinner sp_timeitem;
    private String str_time;
    private String SendTime;
    private String Command;
    private JSONObject jsonObject=null;
    @Override
     public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
     }
     public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle string) {
        if (root == null) {
            root = inflater.inflate(R.layout.fragment_chart, container, false);
        }

        lineChart = (LineChartView)root.findViewById(R.id.lvc_main);
        btntemp=root.findViewById(R.id.temp);
        btnhumidity=root.findViewById(R.id.hemi);
        btnch2o=root.findViewById(R.id.ch2o);
        btnco2=root.findViewById(R.id.co2);
        btntovc=root.findViewById(R.id.tovc);
        btnpm25=root.findViewById(R.id.pm_2_5);
        btnpm10=root.findViewById(R.id.pm_10);
        sp_timeitem = root.findViewById(R.id.sp_timeitem);
         ///////////////////////
         //打开界面显示数据
         SocketGetData("Day","TUTEMP");
         initLineChart("#FFCD41");
         /////////////////////////////
         //选择时间
         sp_timeitem.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
             @Override
             public void onItemSelected(AdapterView<?> parent, View view,
                                        int pos, long id) {

                 String[] languages = getResources().getStringArray(R.array.spinnerTime);
                 Log.e("Time", "你点击的item是:" + languages[pos]);
             }

             @Override
             public void onNothingSelected(AdapterView<?> parent) {
                 // Another interface callback
             }
         });

         btntemp.setOnClickListener(new View.OnClickListener() {
            @Override
             public void onClick(View view) {
                str_time = sp_timeitem.getSelectedItem().toString();
                System.out.println("str_time"+str_time);
                if(str_time.equals("Day")){
                    System.out.println("str_timeDay:"+str_time);
                    SendTime="Day";}
                if(str_time.equals("Week")){
                    System.out.println("str_timeWeek:"+str_time);
                    SendTime="Week";}
                if(str_time.equals("Month")){
                    System.out.println("str_timeMonth:"+str_time);
                    SendTime="Month";}
                SocketGetData(SendTime,"TUTEMP");

                initLineChart("#FFCD41");
            }
        });
         btnhumidity.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 str_time = sp_timeitem.getSelectedItem().toString();
                 System.out.println("str_time"+str_time);
                 if(str_time.equals("Day")){
                     System.out.println("str_timeDay:"+str_time);
                     SendTime="Day";}
                 if(str_time.equals("Week")){
                     System.out.println("str_timeWeek:"+str_time);
                     SendTime="Week";}
                 if(str_time.equals("Month")){
                     System.out.println("str_timeMonth:"+str_time);
                     SendTime="Month";}
                 SocketGetData(SendTime,"TUHUMI");

                 initLineChart("#8BC34A");
             }
         });
         btnch2o.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 str_time = sp_timeitem.getSelectedItem().toString();
                 System.out.println("str_time:"+str_time);
                 if(str_time.equals("Day")){
                     System.out.println("str_timeDay:"+str_time);
                     SendTime="Day";}
                 if(str_time.equals("Week")){
                     System.out.println("str_timeWeek:"+str_time);
                     SendTime="Week";}
                 if(str_time.equals("Month")){
                     System.out.println("str_timeMonth:"+str_time);
                     SendTime="Month";}
                 SocketGetData(SendTime,"TUCH2O");

                 initLineChart("#0DC5DD");
             }
         });
         btnco2.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 str_time = sp_timeitem.getSelectedItem().toString();
                 System.out.println("str_time"+str_time);
                 if(str_time.equals("Day")){
                     System.out.println("str_timeDay:"+str_time);
                     SendTime="Day";}
                 if(str_time.equals("Week")){
                     System.out.println("str_timeWeek:"+str_time);
                     SendTime="Week";}
                 if(str_time.equals("Month")){
                     System.out.println("str_timeMonth:"+str_time);
                     SendTime="Month";}
                 SocketGetData(SendTime,"TU_CO2");

                 initLineChart("#2196F3");
             }
         });
         btntovc.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 str_time = sp_timeitem.getSelectedItem().toString();
                 System.out.println("str_time"+str_time);
                 if(str_time.equals("Day")){
                     System.out.println("str_timeDay:"+str_time);
                     SendTime="Day";}
                 if(str_time.equals("Week")){
                     System.out.println("str_timeWeek:"+str_time);
                     SendTime="Week";}
                 if(str_time.equals("Month")){
                     System.out.println("str_timeMonth:"+str_time);
                     SendTime="Month";}


                 SocketGetData(SendTime,"TUTOVC");

                 initLineChart("#E8DC4C");
             }
         });
         btnpm25.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 str_time = sp_timeitem.getSelectedItem().toString();
                 System.out.println("str_time"+str_time);
                 if(str_time.equals("Day")){
                     System.out.println("str_timeDay:"+str_time);
                     SendTime="Day";}
                 if(str_time.equals("Week")){
                     System.out.println("str_timeWeek:"+str_time);
                     SendTime="Week";}
                 if(str_time.equals("Month")){
                     System.out.println("str_timeMonth:"+str_time);
                     SendTime="Month";}
                 SocketGetData(SendTime,"TUPM25");

                 initLineChart("#E086CD");
             }
         });
         btnpm10.setOnClickListener(new View.OnClickListener() {
             @Override
             public void onClick(View view) {
                 str_time = sp_timeitem.getSelectedItem().toString();
                 System.out.println("str_time"+str_time);
                 if(str_time.equals("Day")){
                     System.out.println("str_timeDay:"+str_time);
                     SendTime="Day";}
                 if(str_time.equals("Week")){
                     System.out.println("str_timeWeek:"+str_time);
                     SendTime="Week";}
                 if(str_time.equals("Month")){
                     System.out.println("str_timeMonth:"+str_time);
                     SendTime="Month";}
                 SocketGetData(SendTime,"TUPM10");

                 initLineChart("#A88EDD");
             }
         });
         return root;
     }

    private void initLineChart(String color){
        Line line = new Line(mPointValues).setColor(Color.parseColor(color));  //
        List<Line> lines = new ArrayList<Line>();
        line.setShape(ValueShape.CIRCLE);//
        line.setCubic(false);//
//	    line.setStrokeWidth(3);//
        line.setFilled(false);//
        line.setHasLabels(true);//
//		line.setHasLabelsOnlyForSelected(true);//
        line.setHasLines(true);//
        line.setHasPoints(true);//
        LineChartValueFormatter formatter = new SimpleLineChartValueFormatter(2);
//        lines.setFormatter(formatter);
        line.setFormatter(formatter);

        lines.add(line);
        LineChartData data = new LineChartData();
        data.setLines(lines);
        line.setShape(ValueShape.DIAMOND);
        Axis axisX = new Axis(); //
        axisX.setHasTiltedLabels(true);  //
//	    axisX.setTextColor(Color.WHITE);  //
        axisX.setTextColor(Color.parseColor("#D6D6D9"));//
        axisX.setHasLines(true);
//	    axisX.setName();  //
        axisX.setTextSize(11);//
        axisX.setMaxLabelChars(7); //
        axisX.setValues(mAxisXValues);  //
        data.setAxisXBottom(axisX); //
//	    data.setAxisXTop(axisX);  //
        axisX.setHasLines(true); //x

        // Y轴是根据数据的大小自动设置Y轴上限
        Axis axisY = new Axis();
        axisY.setName("");
        axisY.setTextSize(11);
        data.setAxisYLeft(axisY);
        //data.setAxisYRight(axisY);

        lineChart.setInteractive(true);
        lineChart.setZoomType(ZoomType.HORIZONTAL);
        lineChart.setMaxZoom((float) 5);
        lineChart.setLineChartData(data);
        lineChart.setVisibility(View.VISIBLE);

        Viewport v = new Viewport(lineChart.getMaximumViewport());
        v.left = 0;
        v.right= 7;
        lineChart.setCurrentViewport(v);
    }

    private void getAxisXLables(ArrayList<String> time){
        for (int i = 0; i < time.size(); i++) {
            mAxisXValues.add(new AxisValue(i).setLabel(time.get(i)));
        }
    }

    private void getAxisPoints(ArrayList<Float> data){
        for (int i = 0; i < data.size(); i++) {
            mPointValues.add(new PointValue(i, data.get(i)));
        }
    }

    private void convertData(String newReturnValue){
        ArrayList<Float>  tempFloat =  new ArrayList<Float>();
        ArrayList<String>  tempTime =  new ArrayList<String>();

        JSONArray tempJA = null;
        try {
            tempJA = new JSONArray(newReturnValue);
            for (int i = 0; i < tempJA.length(); i++) {
                tempFloat.add((float) tempJA.getJSONObject(i).getDouble("item"));
                tempTime.add(tempJA.getJSONObject(i).getString("time"));
            }
            System.out.println("tempFloat:"+tempFloat);
            System.out.println("tempTime:"+tempTime);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        initChart();
        getAxisXLables(tempTime);
        getAxisPoints(tempFloat);

    }

    private void initChart() {
        mPointValues.clear();
        mAxisXValues.clear();

    }

    private void SocketGetData(String info,String command)
    {
        jsonObject = new JSONObject();
        try {
            jsonObject.put("SelectValue", info);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        SocketFactoryR socketFactory = new SocketFactoryR();
        String ReturnValue = socketFactory.ServerSendConn(command, jsonObject);
        System.out.println("SignInReturnValue:" + ReturnValue);

        //截取server编码
        String returnhead = ReturnValue.substring(0, 3);
        System.out.println("serverhead:" + returnhead);

        if (ReturnValue != null && returnhead.equals("TE0")) {
            System.out.println("Data Get success");
            String newReturnValue = ReturnValue.substring(12);
            System.out.println("newReturnValue" + newReturnValue);
            convertData(newReturnValue);
        }

    }
}
