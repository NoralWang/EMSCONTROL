package com.example.emscontrol;

public interface IFragmentCallBack {
    void sendMsgToActivity(String msg);
    String getMsgFromActivity(String msg);

}
